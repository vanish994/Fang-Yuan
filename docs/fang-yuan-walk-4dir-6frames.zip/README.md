# Fang Yuan — Walk 4 directions × 6 frames

Transparent RGBA atlas generated from the Drive reference.

## Row order
1. down / south
2. left / west
3. right / east
4. up / north

Each row has 6 frames. Cell size: 64×64 px.

## QA note
Structural processing completed and produced 24 non-empty frames. Frame-level visual heuristics require review: identity head ratio failed on several frames; phase coverage, leg alternation, torso drift, near-duplicate and seam checks produced warnings. See `qa/frames-qc.json`.
